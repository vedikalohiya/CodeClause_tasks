async function searchRepositories() {
  const query = document.getElementById('search-input').value.trim();
  if (!query) return;

  try {
    const response = await fetch(`https://api.github.com/search/repositories?q=${query}`);
    const data = await response.json();
    displayRepositories(data.items);
  } catch (error) {
    console.error('Error searching repositories:', error);
  }
}

function displayRepositories(repositories) {
  const repositoriesList = document.getElementById('repositories-list');
  repositoriesList.innerHTML = '';

  console.log(repositories); // Log the repositories data to check if it's received correctly

  repositories.forEach(repo => {
    const listItem = document.createElement('li');
    listItem.textContent = repo.full_name;
    listItem.addEventListener('click', () => {
      showRepositoryDetails(repo.owner.login, repo.name);
    });
    repositoriesList.appendChild(listItem);
  });
}

async function showRepositoryDetails(owner, repoName) {
  try {
    const response = await fetch(`https://api.github.com/repos/${owner}/${repoName}`);
    const data = await response.json();
    console.log('Repository details:', data); // Log the data received from the API
    const repositoryDetails = document.getElementById('repository-details');
    repositoryDetails.innerHTML = `
      <h2>${data.full_name}</h2>
      <p>${data.description || 'No description available'}</p>
      <p>Stars: ${data.stargazers_count}</p>
      <p>Forks: ${data.forks_count}</p>
      <p>Language: ${data.language || 'Not specified'}</p>
    `;
  } catch (error) {
    console.error('Error fetching repository details:', error);
  }
}

async function searchUserProfile() {
  const username = document.getElementById('search-input').value.trim();
  if (!username) return;

  try {
    const response = await fetch(`https://api.github.com/users/${username}`);
    const data = await response.json();
    const userProfile = document.getElementById('user-profile');
    userProfile.innerHTML = `
      <h2>User Profile</h2>
      <p>Username: ${data.login}</p>
      <p>Name: ${data.name || 'Not specified'}</p>
      <p>Location: ${data.location || 'Not specified'}</p>
      <p>Public Repositories: ${data.public_repos}</p>
      <p>Followers: ${data.followers}</p>
    `;
  } catch (error) {
    console.error('Error fetching user profile:', error);
  }
}
