const questions = [
    {
        question: 'Who is the founder of Microsoft?',
        answers: [
            { text: 'C.V. Raman', correct: false },
            { text: 'Steve Henry', correct: false },
            { text: 'Andrew Wilson', correct: false },
            { text: 'Bill Gates', correct: true }
        ]
    },
    {
        question: 'Instructions written by a programer for a computer use is called?',
        answers: [
            { text:'Hardware', correct: false },
            { text:'Software Instructions', correct: true },
            { text:'Software', correct: false },
            { text:'System Software', correct: false }
        ]
    },
    {
        question: 'What does IBM stand for?',
        answers: [
            { text: 'International Business Machines', correct: true },
            { text:'International Bureau of Machines', correct: false },
            { text:'Industry Business Model', correct: false },
            { text:'International Business Model',correct: false }
        ]
    },
    {
        question: 'PERL is a',
        answers: [
            { text:'Assembly Level Language', correct: false },
            { text:'Low-Level Language', correct: false },
            { text:'Intermediate Level Language',correct: false },
            { text: 'High-Level Language', correct: true }
        ]
    }
];

const questionElement = document.getElementById("question");
const answerbuttons = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");

let currentQuestionIndex = 0;
let score = 0;

function startQuiz(){
    currentQuestionIndex = 0;
    score = 0;
    nextButton.innerHTML = "Next";
    showQuestion();
}

function showQuestion() {
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    let questionNo = currentQuestionIndex + 1;
    questionElement.innerHTML = questionNo + "." + currentQuestion.question;

    currentQuestion.answers.forEach(answer => {
        const button = document.createElement("button");
        button.innerHTML = answer.text;
        button.classList.add("btn");
        answerbuttons.appendChild(button);
        if(answer.correct){
            button.dataset.correct = answer.correct;
        }
        button.addEventListener("click", selectAnswer);
    });
}


function resetState(){
    nextButton.style.display = "none";
    while(answerbuttons.firstChild){
        answerbuttons.removeChild(answerbuttons.firstChild);
    }
}

function selectAnswer(e){
    const selectedBtn = e.target;
    const isCorrect = selectedBtn.dataset.correct === "true";
    if(isCorrect){
        selectedBtn.classList.add("correct");
        score++;
    }else{
        selectedBtn.classList.add("incorrect");
    }
    Array.from(answerbuttons.children).forEach(button => {
      if(button.dataset.correct === "true"){
        button.classList.add("correct");
      }  
      button.disabled = true;
    });
    nextButton.style.display = "block";
  }

  function showScore() {
    resetState();
    questionElement.innerHTML = `You Scored ${score} out of ${questions.length}!`;
    nextButton.innerHTML = "Play Again";
    nextButton.style.display = "block";
}

function handleNextButton(){
    currentQuestionIndex++;
    if(currentQuestionIndex < questions.length){
        showQuestion();
    }else{
        showScore();
    }
}

nextButton.addEventListener("click", ()=>{
    if(currentQuestionIndex < questions.length){
        handleNextButton();
    }else{
        startQuiz();
    }

});
startQuiz();